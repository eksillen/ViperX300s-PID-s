
"use strict";

let MoveItPlan = require('./MoveItPlan.js')

module.exports = {
  MoveItPlan: MoveItPlan,
};
