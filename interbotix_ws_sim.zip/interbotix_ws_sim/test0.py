#!/usr/bin/env python3
import math, rospy, actionlib
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# ------------------------------------------------------------
# Robot specific
# ------------------------------------------------------------
JOINT_NAMES = [
    "waist", "shoulder", "elbow",
    "forearm_roll", "wrist_angle", "wrist_rotate",
    "left_finger", "right_finger"
]

# rough link lengths [m] – adjust from URDF for accuracy
L1, L2, L3 = 0.135, 0.155, 0.170

moving_sequence = [
    {"waist": 0.0,     "shoulder": -106.0, "elbow": 88.81,
     "forearm_roll": 0.0, "wrist_angle": 45.84, "wrist_rotate": 0.0, "gripper": 0.0},
    {"waist": -85.94,  "shoulder": -85.94, "elbow": 74.48,
     "forearm_roll": 0.0, "wrist_angle": 57.3,  "wrist_rotate": 0.0, "gripper": 0.0},
    {"waist": -85.94,  "shoulder": -85.94, "elbow": 74.48,
     "forearm_roll": 0.0, "wrist_angle": 0.0,   "wrist_rotate": 0.0, "gripper": 114.59},
    {"waist": -85.94,  "shoulder": -85.94, "elbow": 74.48,
     "forearm_roll": 0.0, "wrist_angle": 10.0,  "wrist_rotate": 0.0, "gripper": 0.0},
    {"waist": 0.0,     "shoulder": -106.0, "elbow": 88.81,
     "forearm_roll": 0.0, "wrist_angle": 45.84, "wrist_rotate": 0.0, "gripper": 0.0}
]

MOVE_TIME_S = 3.0
HOLD_TIME_S = 1.0

# ------------------------------------------------------------
_last_js = None
def _js_cb(msg):
    global _last_js
    _last_js = msg

def _current_pos(names):
    if _last_js is None:
        return None
    return {n: _last_js.position[_last_js.name.index(n)] if n in _last_js.name else 0.0
            for n in names}

def _trajectory(start, goal, move_t, hold_t, names):
    p0 = JointTrajectoryPoint(
        positions=[start.get(j, 0.0) for j in names],
        time_from_start=rospy.Duration(0.0))
    p1 = JointTrajectoryPoint(
        positions=[goal.get(j, 0.0) for j in names],
        time_from_start=rospy.Duration(move_t))
    p2 = JointTrajectoryPoint(
        positions=[goal.get(j, 0.0) for j in names],
        time_from_start=rospy.Duration(move_t + hold_t))
    return JointTrajectory(joint_names=names, points=[p0, p1, p2],
                           header=rospy.Header(stamp=rospy.Time.now()))

def convert_pose(pose):
    out = {}
    for k, v in pose.items():
        if k == "gripper":
            out["left_finger"]  = 0.03 if v > 1.0 else 0.0
            out["right_finger"] = -out["left_finger"]
        else:
            out[k] = math.radians(v)
    return out

# ---------- minimal FK (waist + planar chain) ----------
def forward_kinematics(jpos):
    w   = jpos.get("waist", 0.0)
    th1 = jpos.get("shoulder", 0.0)
    th2 = jpos.get("elbow", 0.0)
    th3 = jpos.get("wrist_angle", 0.0)

    y = L1*math.cos(th1) \
      + L2*math.cos(th1+th2) \
      + L3*math.cos(th1+th2+th3)
    z = L1*math.sin(th1) \
      + L2*math.sin(th1+th2) \
      + L3*math.sin(th1+th2+th3)

    x = y*math.sin(w)
    y = y*math.cos(w)
    return (x, y, z)

# ------------------------------------------------------------
def main():
    rospy.init_node("vx300s_sequence_player")
    rospy.Subscriber("/joint_states", JointState, _js_cb)
    arm_cli = actionlib.SimpleActionClient(
        "/joint_trajectory_controller/follow_joint_trajectory",
        FollowJointTrajectoryAction)
    rospy.loginfo("Waiting for action server ...")
    arm_cli.wait_for_server()

    while not rospy.is_shutdown() and _last_js is None:
        rospy.sleep(0.1)

    log_xyz, plan_xyz = [], []
    log_time = []

    def _log(event):
        if _last_js is None:
            return
        log_time.append(rospy.get_time())
        jdict = {n: 0.0 for n in JOINT_NAMES}
        for n in _last_js.name:
            jdict[n] = _last_js.position[_last_js.name.index(n)]
        log_xyz.append(forward_kinematics(jdict))

    timer = rospy.Timer(rospy.Duration(0.05), _log)

    # -------- run sequence -------------
    for pose in moving_sequence:
        cur       = _current_pos(JOINT_NAMES)
        goal_pos  = convert_pose(pose)

        # plan point for ideal path
        plan_xyz.append(forward_kinematics(goal_pos))

        traj = _trajectory(cur, goal_pos, MOVE_TIME_S, HOLD_TIME_S, JOINT_NAMES)
        goal = FollowJointTrajectoryGoal(trajectory=traj,
                                         goal_time_tolerance=rospy.Duration(HOLD_TIME_S))
        arm_cli.send_goal(goal)
        arm_cli.wait_for_result(rospy.Duration(MOVE_TIME_S + 2.0))

    rospy.sleep(2.0)
    timer.shutdown()

    if not log_xyz:
        rospy.logwarn("No joint_state data captured.")
        return

    # ---------- 3-D plot ----------
    fig = plt.figure(figsize=(8,6))
    ax  = fig.add_subplot(111, projection='3d')

    xs, ys, zs = zip(*log_xyz)
    ax.plot(xs, ys, zs, lw=2, label="Actual path")

    px, py, pz = zip(*plan_xyz)
    ax.plot(px, py, pz, 'r--', lw=2, label="Planned path")

    ax.set_title("End-Effector Trajectory")
    ax.set_xlabel("X [m]")
    ax.set_ylabel("Y [m]")
    ax.set_zlabel("Z [m]")
    ax.legend()
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
