# interbotix_ros_slate

This metapackage groups together the core ROS Packages for the Interbotix Slate mobile base.
