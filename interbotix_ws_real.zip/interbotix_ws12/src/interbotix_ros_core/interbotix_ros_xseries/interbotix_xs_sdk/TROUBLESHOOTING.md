# Troubleshooting a Dynamixel-based Robot

See the [Troubleshooting Guide](https://docs.trossenrobotics.com/interbotix_xsarms_docs/troubleshooting.html) on the Interbotix X-Series Arms documentation site.
