# interbotix_perception_toolbox

This metapackage groups together the packages for the Interbotix Perception Toolbox.
