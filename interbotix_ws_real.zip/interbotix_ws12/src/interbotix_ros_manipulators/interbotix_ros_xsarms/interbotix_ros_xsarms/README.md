# interbotix_ros_xsarms

This metapackage groups together the core ROS Packages for the Interbotix X-Series Arms.
