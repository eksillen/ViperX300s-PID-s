
"use strict";

let ArmJoy = require('./ArmJoy.js');
let JointSingleCommand = require('./JointSingleCommand.js');
let TurretJoy = require('./TurretJoy.js');
let JointTemps = require('./JointTemps.js');
let JointTrajectoryCommand = require('./JointTrajectoryCommand.js');
let JointGroupCommand = require('./JointGroupCommand.js');
let LocobotJoy = require('./LocobotJoy.js');
let HexJoy = require('./HexJoy.js');

module.exports = {
  ArmJoy: ArmJoy,
  JointSingleCommand: JointSingleCommand,
  TurretJoy: TurretJoy,
  JointTemps: JointTemps,
  JointTrajectoryCommand: JointTrajectoryCommand,
  JointGroupCommand: JointGroupCommand,
  LocobotJoy: LocobotJoy,
  HexJoy: HexJoy,
};
